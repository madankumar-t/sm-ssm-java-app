rootProject.name = "aws-sm-ssm-demo"
