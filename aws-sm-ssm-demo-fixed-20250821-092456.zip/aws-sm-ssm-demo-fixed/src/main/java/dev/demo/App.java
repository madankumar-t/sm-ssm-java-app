
package dev.demo;

import software.amazon.awssdk.auth.credentials.AwsCredentialsProvider;
import software.amazon.awssdk.auth.credentials.DefaultCredentialsProvider;
import software.amazon.awssdk.core.exception.SdkClientException;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.regions.providers.DefaultAwsRegionProviderChain;
import software.amazon.awssdk.services.secretsmanager.SecretsManagerClient;
import software.amazon.awssdk.services.secretsmanager.model.GetSecretValueRequest;
import software.amazon.awssdk.services.secretsmanager.model.GetSecretValueResponse;
import software.amazon.awssdk.services.secretsmanager.model.SecretsManagerException;
import software.amazon.awssdk.services.ssm.SsmClient;
import software.amazon.awssdk.services.ssm.model.GetParameterRequest;
import software.amazon.awssdk.services.ssm.model.GetParameterResponse;
import software.amazon.awssdk.services.ssm.model.SsmException;

public class App {
  public static void main(String[] args) {
    if (args.length < 2) {
      System.err.println("Usage: java -jar app.jar <SECRET_ID> <PARAM_NAME>");
      System.err.println("Use AWS profiles via AWS_PROFILE or -Daws.profile, region from ~/.aws/config.");
      System.exit(2);
    }
    final String secretId = args[0];
    final String paramName = args[1];

    final AwsCredentialsProvider creds = DefaultCredentialsProvider.create();

    final Region region;
    try {
      region = new DefaultAwsRegionProviderChain().getRegion();
    } catch (SdkClientException e) {
      System.err.println("No region found. Configure one in ~/.aws/config for the selected profile, or set AWS_REGION/-Daws.region.\n" + e.getMessage());
      System.exit(2);
      return;
    }

    try (SecretsManagerClient sm = SecretsManagerClient.builder().credentialsProvider(creds).region(region).build();
         SsmClient ssm = SsmClient.builder().credentialsProvider(creds).region(region).build()) {

      GetSecretValueResponse s = sm.getSecretValue(GetSecretValueRequest.builder().secretId(secretId).build());
      String secret = s.secretString() != null ? s.secretString() : "<binary secret>";

      GetParameterResponse p = ssm.getParameter(GetParameterRequest.builder().name(paramName).withDecryption(true).build());
      String param = p.parameter() != null ? p.parameter().value() : null;

      String profile = System.getenv().getOrDefault("AWS_PROFILE", System.getProperty("aws.profile", "(default)"));
      System.out.println("Profile: " + profile);
      System.out.println("Region : " + region.id());
      System.out.println("Secret : " + secretId + " = " + secret);
      System.out.println("Param  : " + paramName + " = " + param);
    } catch (SecretsManagerException e) {
      System.err.println("Secrets Manager error: " + e.awsErrorDetails().errorMessage());
      System.exit(1);
    } catch (SsmException e) {
      System.err.println("SSM error: " + e.awsErrorDetails().errorMessage());
      System.exit(1);
    }
  }
}
