
# aws-sm-ssm-demo (Gradle, Java 17, AWS SDK v2)

A minimal console app that reads one value from **AWS Secrets Manager** and one from **SSM Parameter Store** using the **default AWS profile** chain (supports static keys, role chaining, and AWS SSO).

## Build & run (with included Gradle wrapper)
```bash
# requirements for the wrapper
sudo apt-get update && sudo apt-get install -y curl unzip   # or use your package manager

# pick a profile (static or SSO) and ensure region is set in ~/.aws/config
export AWS_PROFILE=myapp
aws sso login --profile myapp   # if using SSO

# run
./gradlew run --args='"my/app/secret" "/my/app/db_password"'

# or build a fat jar
./gradlew shadowJar
AWS_PROFILE=myapp java -jar build/libs/aws-sm-ssm-demo-1.0.0-all.jar "my/app/secret" "/my/app/db_password"
```

## AWS config examples
`~/.aws/credentials`:
```ini
[myapp]
aws_access_key_id = AKIA...
aws_secret_access_key = ...
```

`~/.aws/config`:
```ini
[profile myapp]
region = ap-south-1
output = json

[profile myapp-sso]
sso_start_url = https://your-sso-start.awsapps.com/start
sso_region    = ap-south-1
sso_account_id = 123456789012
sso_role_name  = MyRole
region = ap-south-1
```

Run with a specific profile:
```bash
AWS_PROFILE=myapp ./gradlew run --args='"my/app/secret" "/my/app/db_password"'
# or
./gradlew run --args='"my/app/secret" "/my/app/db_password"' -Daws.profile=myapp
```
