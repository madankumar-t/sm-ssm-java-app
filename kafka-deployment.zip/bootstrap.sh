#!/bin/bash
set -e

CLUSTER_NAME="uat-rlr-eks-cluster"
AWS_REGION="us-east-2"
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)

echo "[1/5] Associate IAM OIDC Provider..."
eksctl utils associate-iam-oidc-provider   --region $AWS_REGION   --cluster $CLUSTER_NAME   --approve

echo "[2/5] Create IAM Role for EBS CSI..."
cat > trust-policy.json <<EOF
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "Federated": "arn:aws:iam::$ACCOUNT_ID:oidc-provider/oidc.eks.$AWS_REGION.amazonaws.com/id/$(aws eks describe-cluster --region $AWS_REGION --name $CLUSTER_NAME --query "cluster.identity.oidc.issuer" --output text | cut -d'/' -f5)"
      },
      "Action": "sts:AssumeRoleWithWebIdentity",
      "Condition": {
        "StringEquals": {
          "oidc.eks.$AWS_REGION.amazonaws.com/id/$(aws eks describe-cluster --region $AWS_REGION --name $CLUSTER_NAME --query "cluster.identity.oidc.issuer" --output text | cut -d'/' -f5):sub": "system:serviceaccount:kube-system:ebs-csi-controller-sa"
        }
      }
    }
  ]
}
EOF

aws iam create-role   --role-name AmazonEKS_EBS_CSI_DriverRole   --assume-role-policy-document file://trust-policy.json || echo "Role already exists, skipping."

aws iam attach-role-policy   --role-name AmazonEKS_EBS_CSI_DriverRole   --policy-arn arn:aws:iam::aws:policy/service-role/AmazonEBSCSIDriverPolicy || true

echo "[3/5] Create ServiceAccount with IAM Role..."
eksctl create iamserviceaccount   --region $AWS_REGION   --name ebs-csi-controller-sa   --namespace kube-system   --cluster $CLUSTER_NAME   --attach-policy-arn arn:aws:iam::aws:policy/service-role/AmazonEBSCSIDriverPolicy   --override-existing-serviceaccounts   --approve

echo "[4/5] Install AWS EBS CSI Driver addon..."
eksctl create addon   --name aws-ebs-csi-driver   --cluster $CLUSTER_NAME   --region $AWS_REGION   --service-account-role-arn arn:aws:iam::$ACCOUNT_ID:role/AmazonEKS_EBS_CSI_DriverRole   --force

echo "[5/5] Bootstrap completed successfully."
