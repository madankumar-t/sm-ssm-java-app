# Terraform Stack: VPC + EKS

This project provisions a VPC and an EKS cluster using Spacelift modules.

## Structure

- `main.tf` — Root configuration wiring VPC and EKS modules
- `variables.tf` — Input variables
- `outputs.tf` — Key outputs
- `providers.tf` — AWS provider config
- `versions.tf` — Terraform + provider versions
- `terraform.tfvars` — Example variable values (edit before apply)

## Usage

1. Initialize Terraform:

   ```bash
   terraform init
   ```

2. Review the plan:

   ```bash
   terraform plan
   ```

3. Apply the configuration:

   ```bash
   terraform apply
   ```

## Notes

- The EKS cluster will use **private subnets** from the VPC module.
- Adjust versions of EKS add-ons (CoreDNS, kube-proxy, VPC CNI) to match your AWS region/EKS version.
- Customize tags and labels for your environment.

---
Generated for Spacelift integration.
